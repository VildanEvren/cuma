﻿<?php

@mysql_select_db("takipistemi" , mysql_connect("localhost","root","")) 
    or die("Bağlanamadı");
    mysql_query("SET NAMES UTF8");
?>