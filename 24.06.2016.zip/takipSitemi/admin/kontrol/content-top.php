<!-- Page Head -->
			<h2>Hoşgeldin!</h2>
			
			<ul class="shortcut-buttons-set">
				
				
				
				<li><a class="shortcut-button" href="index.php?Go=konum"><span>
					<img src="images/icons/icon.png" alt="icon" /><br />
					Konumlar
				</span></a></li>
                
				
				<li><a class="shortcut-button" href="index.php?Go=Personel"><span>
					<img src="images/icons/ogr.png" alt="icon" /><br />
				Personel Kayıt</span></a></li>
				
				
                    
                    <li><a class="shortcut-button" href="index.php?Go=Ders"><span>
					<img src="images/icons/pencil_48.png" alt="icon" /><br />
				xxxxx</span></a></li>
                    
                    
                    
				
			</ul><!-- End .shortcut-buttons-set -->