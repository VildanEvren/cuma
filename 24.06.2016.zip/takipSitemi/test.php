<?php
session_start();
$kordinat = $_GET["kordinat"];
//date_default_timezone_set('Europe/Konya');

echo($kordinat );

$kordinat = $_GET["kordinat"];
$enlem = substr($kordinat,0,10);
$boylam = substr($kordinat,11,23);
$tarih = date('Y.m.d');
$saat = date('H:i');
$Personel = $_SESSION["user"];

include("baglanti.php");
$sorgu=mysql_query("insert into konum (Personel,enlem,boylam,tarih,saat) values ('$Personel','$enlem','$boylam','$tarih','$saat')");



if($sorgu){
    echo 'Kay�t Eklendi.';
}else{
    echo 'Kay�t Eklenemedi!';
} 
?>
